package ProjetoPOO;
import view.TelaInicial;

public class ProjetoPOO {
    
    public static void main(String[] args) {
        TelaInicial viewTelaInicial = new TelaInicial();
        viewTelaInicial.setVisible(true);
    }
    
}
