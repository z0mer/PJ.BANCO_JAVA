package model;

public class Gerente extends Pessoa {

    public Gerente(String nome, String cpf) {
        super(nome, cpf);
    }
}